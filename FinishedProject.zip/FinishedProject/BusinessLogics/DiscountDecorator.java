public interface Discount {
    double applyDiscount(double price);
}

// Abstract decorator class
public abstract class DiscountDecorator implements Discount {
    protected Discount decoratedDiscount;

    public DiscountDecorator(Discount decoratedDiscount) {
        this.decoratedDiscount = decoratedDiscount;
    }

    public double applyDiscount(double price) {
        return decoratedDiscount.applyDiscount(price);
    }
}

// Concrete Decorator Example
public class SeasonalDiscountDecorator extends DiscountDecorator {
    public SeasonalDiscountDecorator(Discount decoratedDiscount) {
        super(decoratedDiscount);
    }

    public double applyDiscount(double price) {
        // Assuming a 10% seasonal discount
        return super.applyDiscount(price) * 0.9;
    }
}
