package Main;
public class mainController {
    
    public static Boolean isLoggedIn(){


        return false;
    }
}
