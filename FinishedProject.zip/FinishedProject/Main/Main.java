package Main;

import Login.LoginGUI;

public class Main {
    public static void main(String[] args) {
       
        new LoginGUI().setVisible(true);
    }
}
